package com.furina.android

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }

        val title = TextView(this).apply {
            text = "FURINA Bot"
            textSize = 28f
        }

        val status = TextView(this).apply {
            text = "\nAndroid wrapper berhasil dibuat.\n\nTahap ini belum menjalankan engine WhatsApp Node.js."
            textSize = 16f
        }

        layout.addView(title)
        layout.addView(status)
        setContentView(layout)
    }
}
