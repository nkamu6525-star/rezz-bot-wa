# FURINA Android Project

This is a minimal Android wrapper/build project for GitHub Actions.

Important: this APK is NOT yet the complete WhatsApp bot. The original Node.js bot uses native/heavy dependencies that need an Android-compatible runtime/port before the actual bot can run as a standalone APK.
